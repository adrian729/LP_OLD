#ifndef __PCCTS_STDARG_H__
#define __PCCTS_STDARG_H__

#ifdef PCCTS_USE_NAMESPACE_STD
#include <cstdarg>
#else
#include <stdarg.h>
#endif

#endif
